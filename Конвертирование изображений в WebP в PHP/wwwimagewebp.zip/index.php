<?php

function create_webp(string $src, int $quality = 100): string
{
    $dir = pathinfo($src, PATHINFO_DIRNAME);
    $name = pathinfo($src, PATHINFO_FILENAME);
    $ext = pathinfo($src, PATHINFO_EXTENSION);
    $dest = "{$dir}/{$name}_{$ext}.webp";
    $is_alpha = false;

    if (mime_content_type($src) == 'image/png') {
        $is_alpha = true;
        $img = imagecreatefrompng($src);
    } elseif (mime_content_type($src) == 'image/jpeg') {
        $img = imagecreatefromjpeg($src);
    } else {
        return $src;
    }

    if ($is_alpha) {
        imagepalettetotruecolor($img);
        imagealphablending($img, true);
        imagesavealpha($img, true);
    }

    imagewebp($img, $dest, $quality);
    return $dest;
}

var_dump(create_webp(__DIR__ . '/smoke.png', 70));
var_dump(create_webp(__DIR__ . '/panda.jpg', 60));
var_dump(create_webp(__DIR__ . '/file.gif', 60));
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        body {
            /*background-color: #000;*/
        }
        img {
            max-width: 400px;
            display: block;
        }
    </style>
</head>
<body>

<img src="smoke.png" alt="">
<img src="smoke_png.webp" alt="">
<img src="panda.jpg" alt="">
<img src="panda_jpg.webp" alt="">

</body>
</html>
