/**
 * index.js
 * Paul Krishnamurthy 2016
 *
 * https://paulkr.com
 * paul@paulkr.com
 */

$(document).ready(function () {
	$(".demo-img").blowup({
		background : "#FCEBB6"
	});
})
