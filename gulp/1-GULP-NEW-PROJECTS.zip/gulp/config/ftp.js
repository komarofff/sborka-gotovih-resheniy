export let configFTP = {
  host: 'stark77.beget.tech', // Адрес FTP сервера
  user: 'stark77_tech', // Имя пользователя
  password: 'stark2536!MK!', // Пароль
  parallel: 20 // Кол-во одновременных потоков
}