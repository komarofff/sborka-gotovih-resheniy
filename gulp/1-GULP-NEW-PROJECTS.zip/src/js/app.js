// const topMenu = document.querySelector('.top-menu')
// topMenu.addEventListener('mouseover',(e)=>{
//     if(e.target.classList.contains('open-drop')){
//         e.target.parentNode.querySelector('.subcategory-2').style.display = 'flex'
//     }
//
// })