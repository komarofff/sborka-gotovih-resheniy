$('#slider-price').slick({
    infinite: true,
    dots: false,
    slidesToShow:3,
    slidesToScroll: 1,
    centerPadding: '0px'
});